import cv2
from matplotlib.pyplot import*
import numpy as np
import pickle
from FeatureDetectors import *

calibrationFile = 'CamCalib.pckl'

#parameters for median blur 
kernalSize = 11              #Aperture linear size; it must be odd and greater than 1, for example: 3, 5, 7 ...

#adaptiveThreshold parameters
thresholdingBlockSize = 15    #Size of a pixel neighborhood that is used to calculate a threshold value for the pixel: 3, 5, 7, and so on.
thresholdingConstant = 2    #Constant subtracted from the mean or weighted mean 

#Canny edge detector parameters
edgeThreshold1 = 100          #First threshold for the hysteresis procedure
edgeThreshold2 = 150          #Second threshold for the hysteresis procedure
edgeApertureSize = 3        #Aperture size for the Sobel() operator

#HOUGH transform parameters
angleRange =  pi/180              #Angle resolution of the accumulator in radians
distanceRange = 1             #Distance resolution of the accumulator in pixels
lineThreshold =  100            #Accumulator threshold parameter. Only those lines are returned that get enough votes (>threshold)

fieldOfView = 72              #Horizontal Field of View

detectorObj = IMAGE_DOORS(kernalSize,thresholdingBlockSize,thresholdingConstant,
                          edgeThreshold1,edgeThreshold2,edgeApertureSize,
                          angleRange,distanceRange,lineThreshold,fieldOfView,1)


def vis(img):
  figObj = figure()
  imgObj = figObj.add_subplot(111)
  imgObj.set_xticks([])
  imgObj.set_yticks([])
  imgObj.imshow(img,cmap="gray")
  draw()

def _cleanImage(image):
  with open(calibrationFile) as f:
    obj = pickle.load(f)
  (tf,camera_matrix,dist_coefs,Hom)=obj
  h,  w = image.shape[:2]
  newcameramtx, roi=cv2.getOptimalNewCameraMatrix(camera_matrix,dist_coefs,(w,h),1,(w,h))
  dst = cv2.undistort(image, camera_matrix, dist_coefs, None, newcameramtx)
  x,y,w,h = roi
  dst = dst[y:y+h, x:x+w]
  return dst

# Draws lines on an image given Hough coordinates
def drawLines(image,rho,theta=0):
  a = np.cos(theta)
  b = np.sin(theta)
  x0 = a*rho
  y0 = b*rho
  x1 = int(x0 + 1000*(-b))
  y1 = int(y0 + 1000*(a))
  x2 = int(x0 - 1000*(-b))
  y2 = int(y0 - 1000*(a))
  cv2.line(image,(x1,y1),(x2,y2),(255,0,0),1)
  return image

def drawDoor(door, image):
  topLeft,topRight, botLeft, botRight = door.getCorners()
  cv2.line(image,topLeft,topRight,(255,0,255),1)
  cv2.line(image,topLeft,botLeft,(255,0,255),1)
  cv2.line(image,topRight,botRight,(255,0,255),1)
  image = cv2.circle(image, topLeft, 10, (0,0,255))
  image = cv2.circle(image, topRight, 10, (0,0,255))
  #image = drawLines(image, door.leftFrame[0], door.leftFrame[1])
  #image = drawLines(image, door.rightFrame[0], door.rightFrame[1])
  #image = drawLines(image, door.topFrame[0], door.topFrame[1])
  return image
  
def main():  
  cam = cv2.VideoCapture(1)  
  while True:
    ret, img = cam.read()
    image = _cleanImage(img)
    doors = detectorObj.get_landmarks(image)
    if doors:
      for door in doors:
        image=drawDoor(door, image)
    cv2.imshow("Image", image)
    key = cv2.waitKey(10)
      
if __name__ == '__main__':
  main()

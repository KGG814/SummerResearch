from numpy import *
from math import degrees, sin, cos, hypot, atan2, pi
import random
from scipy.optimize import curve_fit
from cv2 import *
import os

class DOOR(object):
  def __init__(self, leftFrame, rightFrame, topFrame):
    self.leftFrame = leftFrame
    self.rightFrame = rightFrame
    self.topFrame = topFrame
    
  # Extracts the corners from this door object
  # Currently assumes bottom of door is bottom of image
  def getCorners(self):
    # m = -cos(theta)/sin(theta)
    # b = rho/sin(theta)
    mTop = -cos(self.topFrame[1])/sin(self.topFrame[1])  
    bTop = self.topFrame[0]/sin(self.topFrame[1])
    
    # Calculation of top left and bottom left corners of door
    if self.leftFrame[1] == 0.0:
      xLeftTop = self.leftFrame[0]
      botLeft = (int(self.leftFrame[0]),316)
    else:
      bLeft = self.leftFrame[0]/sin(self.leftFrame[1])
      mLeft = -cos(self.leftFrame[1])/sin(self.leftFrame[1])  
      xLeftTop = abs((bTop-bLeft)/(mTop-mLeft))
      botLeft = (abs(int((-bLeft+316)/mLeft)), 316)
    
    # Calculation of rop right and bottom right corners of door
    if self.rightFrame[1] == 0.0:
      xRightTop = self.rightFrame[0]
      botRight = (int(self.rightFrame[0]),316)      
    else: 
      bRight = self.rightFrame[0]/sin(self.rightFrame[1])  
      mRight = abs(-cos(self.rightFrame[1])/sin(self.rightFrame[1]))
      xRightTop = (bTop-bRight)/(mTop-mRight)
      botRight = (abs(int((-bRight+316)/mRight)), 316)
      
    topLeft = int(xLeftTop), int(mTop*xLeftTop+bTop)
    topRight = int(xRightTop), int(mTop*xRightTop+bTop)
    return topLeft, topRight, botLeft, botRight

class IMAGE_DOORS(object):
  """Class to find doors in on-board camera images""" 

  def __init__(self,kernalSize,thresholdingBlockSize,thresholdingConstant,
               edgeThreshold1,edgeThreshold2,edgeApertureSize,angleRange,
               distanceRange,lineThreshold,fieldOfView,angularError):
    
    #parameters for median blur 
    self.kernalSize = kernalSize
    #Aperture linear size; it must be odd and greater than 1, 
    #for example: 3, 5, 7 ...

    #adaptiveThreshold parameters
    #Size of a pixel neighborhood that is used to calculate a threshold value for the pixel: 3, 5, 7, and so on.
    self.thresholdingBlockSize = thresholdingBlockSize
    #Constant subtracted from the mean or weighted mean     
    self.thresholdingConstant = thresholdingConstant    

    #Canny edge detector parameters
    #First threshold for the hysteresis procedure
    self.edgeThreshold1 = edgeThreshold1
    #Second threshold for the hysteresis procedure
    self.edgeThreshold2 = edgeThreshold2      
    #Aperture size for the Sobel() operator    
    self.edgeApertureSize = edgeApertureSize        

    #HOUGH transform parameters
    #Angle resolution of the accumulator in radians
    self.angleRange = angleRange               
    #Distance resolution of the accumulator in pixels
    self.distanceRange = distanceRange             
    #Accumulator threshold parameter.
    #Only those lines are returned that get enough votes (>threshold)
    self.lineThreshold = lineThreshold            
    #Horizontal Field of View
    self.fieldOfView = fieldOfView  
    #EKF Error variable for Covariance            
    self.angularError = angularError            
    self.landmarkType = "Image Line"

  def get_landmarks(self,image):
    #os.system('clear')
    """Hough transform based lines extractor"""
    verticalLines = []
    horizontalLines = []
    #Convert image to gray
    gray = cvtColor(image,COLOR_BGR2GRAY)
    #deNoise image
    gray = medianBlur(gray,self.kernalSize)
    #Convert into a binary image
    th2 = adaptiveThreshold(gray,255,ADAPTIVE_THRESH_MEAN_C,THRESH_BINARY,
                            self.thresholdingBlockSize,self.thresholdingConstant)
    #Find edges in image
    edges = Canny(th2,self.edgeThreshold1,self.edgeThreshold2,
                  apertureSize = self.edgeApertureSize)
                  
    #Find vertical lines in image
    lines = HoughLines (edges,self.distanceRange,
                        self.angleRange,100)
    if lines is not None:
      for line in lines:      
        for rho,theta in line:
          if theta < 0.3 or theta > math.pi-0.3:
            angle = (rho*self.fieldOfView/image.shape[1])-(self.fieldOfView/2)
            verticalLines.append((rho, theta))
            
    lines = HoughLines (edges,self.distanceRange,
                        self.angleRange,100)      

    #Find horizontal lines in image
    if lines is not None:
      for line in lines:      
        for rho,theta in line:
          if 1.553 < theta < 1.588:
            angle = (rho*self.fieldOfView/image.shape[1])-(self.fieldOfView/2)
            horizontalLines.append((rho, theta))
    horizontalLines.sort(key = lambda x: x[0])
    doors = self.findDoors(verticalLines,self.cleanLines(horizontalLines))
    return doors

  # Removes multiple lines near each other
  #TODO needs to be tuned properly, or replaced with something else
  def cleanLines(self, lines):
    prevRho = 0.0
    cleanedLines = []
    for line in lines:
      rho = line[0]
      if rho - prevRho > 20 or prevRho == 0.0:
        prevRho = rho
        cleanedLines.append(line)
    return cleanedLines
    
  # Find the door in an image, given the lines
  def findDoors(self, verticalLines, horizontalLines):
    doors = []
    centre = 233.0
    leftFrame = (0.0,0.0)
    rightFrame = (centre*2,0.0)
    if horizontalLines:
      for line in verticalLines:
        rho = line[0]
        if leftFrame[0] < rho < centre: 
          leftFrame = line
        elif centre < rho < rightFrame[0]:
          rightFrame = line
        else:
          break
      if leftFrame != (0.0,0.0) and rightFrame != (centre*2,0.0):
        doors.append(DOOR(leftFrame, rightFrame, horizontalLines[0]))
    return doors
    
    
